function precio_unidad(){
    var precio_compra = parseFloat(document.getElementById('precio_compra').value);
    var unidades_compradas = parseInt(document.getElementById('unidades_compradas').value);
    var precio_envio = parseFloat(document.getElementById('precio_envio').value);
    var gastos_extras = parseFloat(document.getElementById('gastos_extras').value) || 0;
    
    
    
    precio_compra_unidad=0;
    precio_compra_unidad=(precio_compra+precio_envio+gastos_extras)/unidades_compradas;

    gasto_total=0;
    gasto_total=precio_compra+precio_envio+gastos_extras;

    document.getElementById('precio_compra_unidad').value= precio_compra_unidad.toFixed(2)
    document.getElementById('gasto_total').value= gasto_total.toFixed(2)

}

function ganancia(){

    var precio_compra = parseFloat(document.getElementById('precio_compra').value);
    var unidades_compradas = parseInt(document.getElementById('unidades_compradas').value);
    var precio_envio = parseFloat(document.getElementById('precio_envio').value);
    var gastos_extras = parseFloat(document.getElementById('gastos_extras').value) || 0;
    var precio_venta_unidad = parseFloat(document.getElementById('precio_venta_unidad').value);


let precio_compra_unidad=0;
let ganancia_por_unidad=0;
let ganancia_total=0;
let capital_final=0;


precio_compra_unidad=(precio_compra+precio_envio+gastos_extras)/unidades_compradas;
ganancia_por_unidad= precio_venta_unidad-precio_compra_unidad;
ganancia_total=ganancia_por_unidad*unidades_compradas;
capital_final=precio_venta_unidad*unidades_compradas;

document.getElementById('ganancia_por_unidad').value= ganancia_por_unidad.toFixed(2)
document.getElementById('ganancia_total').value= ganancia_total.toFixed(2)
document.getElementById('capital_final').value= capital_final.toFixed(2)


}